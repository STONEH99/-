package com.sunlab.notebook

import android.app.Application
import com.sunlab.notebook.data.database.SunLabDatabase
import com.sunlab.notebook.data.repository.NotebookRepository
import com.sunlab.notebook.data.storage.SettingsStore

/** Application class; holds the app-wide singletons (manual dependency injection). */
class SunLabApp : Application() {
    val database: SunLabDatabase by lazy { SunLabDatabase.create(this) }
    val notebookRepository: NotebookRepository by lazy { NotebookRepository(database) }
    val settings: SettingsStore by lazy { SettingsStore(this) }
}
