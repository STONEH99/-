package com.sunlab.notebook.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.sunlab.notebook.data.models.FolderEntity
import com.sunlab.notebook.data.models.NotebookEntity
import com.sunlab.notebook.data.models.PageEntity

@Database(
    entities = [FolderEntity::class, NotebookEntity::class, PageEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class SunLabDatabase : RoomDatabase() {

    abstract fun notebookDao(): NotebookDao

    companion object {
        fun create(context: Context): SunLabDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                SunLabDatabase::class.java,
                "sunlab.db",
            ).build()
    }
}
