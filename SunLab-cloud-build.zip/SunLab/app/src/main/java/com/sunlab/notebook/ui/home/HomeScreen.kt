package com.sunlab.notebook.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sunlab.notebook.R
import com.sunlab.notebook.data.models.NotebookWithPageCount
import com.sunlab.notebook.data.storage.LibraryLayout
import com.sunlab.notebook.ui.theme.PaperWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showCreateDialog by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineMedium,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.create_notebook)) },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LayoutToggle(
                current = state.layout,
                onSelect = viewModel::setLayout,
            )
            when {
                !state.loaded -> Unit
                state.notebooks.isEmpty() -> EmptyLibrary()
                state.layout == LibraryLayout.GRID -> NotebookGrid(
                    items = state.notebooks,
                    onToggleFavorite = viewModel::toggleFavorite,
                )
                else -> NotebookList(
                    items = state.notebooks,
                    onToggleFavorite = viewModel::toggleFavorite,
                )
            }
        }
    }

    if (showCreateDialog) {
        CreateNotebookDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { title ->
                viewModel.createNotebook(title)
                showCreateDialog = false
            },
        )
    }
}

@Composable
private fun LayoutToggle(current: LibraryLayout, onSelect: (LibraryLayout) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        FilterChip(
            selected = current == LibraryLayout.GRID,
            onClick = { onSelect(LibraryLayout.GRID) },
            label = { Text(stringResource(R.string.library_layout_grid)) },
        )
        FilterChip(
            selected = current == LibraryLayout.LIST,
            onClick = { onSelect(LibraryLayout.LIST) },
            label = { Text(stringResource(R.string.library_layout_list)) },
        )
    }
}

@Composable
private fun EmptyLibrary() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(R.string.empty_library_title),
            style = MaterialTheme.typography.titleLarge,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.empty_library_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun NotebookGrid(
    items: List<NotebookWithPageCount>,
    onToggleFavorite: (NotebookWithPageCount) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        items(items, key = { it.notebook.id }) { item ->
            Column {
                NotebookCover(
                    color = Color(item.notebook.coverColor),
                    title = item.displayTitle(),
                    modifier = Modifier.fillMaxWidth().aspectRatio(3f / 4f),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NotebookMeta(item, Modifier.weight(1f).padding(top = 8.dp))
                    FavoriteButton(item, onToggleFavorite)
                }
            }
        }
    }
}

@Composable
private fun NotebookList(
    items: List<NotebookWithPageCount>,
    onToggleFavorite: (NotebookWithPageCount) -> Unit,
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(items, key = { it.notebook.id }) { item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                NotebookCover(
                    color = Color(item.notebook.coverColor),
                    title = "",
                    modifier = Modifier.width(48.dp).aspectRatio(3f / 4f),
                )
                NotebookMeta(item, Modifier.weight(1f).padding(horizontal = 16.dp))
                FavoriteButton(item, onToggleFavorite)
            }
        }
    }
}

@Composable
private fun NotebookMeta(item: NotebookWithPageCount, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(
            text = item.displayTitle(),
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = LocalContext.current.resources.getQuantityString(
                R.plurals.page_count, item.pageCount, item.pageCount,
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun FavoriteButton(
    item: NotebookWithPageCount,
    onToggleFavorite: (NotebookWithPageCount) -> Unit,
) {
    val favorite = item.notebook.isFavorite
    IconButton(onClick = { onToggleFavorite(item) }) {
        Icon(
            imageVector = if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = stringResource(
                if (favorite) R.string.remove_favorite else R.string.add_favorite,
            ),
            tint = if (favorite) MaterialTheme.colorScheme.secondary
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Simple cover: colored board with a darker spine on the start edge (RTL-aware). */
@Composable
private fun NotebookCover(color: Color, title: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(
                RoundedCornerShape(
                    topStart = 4.dp, bottomStart = 4.dp, topEnd = 14.dp, bottomEnd = 14.dp,
                )
            )
            .background(color),
    ) {
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .width(10.dp)
                .background(Color.Black.copy(alpha = 0.18f))
        )
        if (title.isNotEmpty()) {
            Text(
                text = title,
                color = PaperWhite,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.Center).padding(horizontal = 20.dp),
            )
        }
    }
}

@Composable
private fun CreateNotebookDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var title by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.create_notebook)) },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                label = { Text(stringResource(R.string.notebook_title_hint)) },
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(title) }, enabled = title.isNotBlank()) {
                Text(stringResource(R.string.create))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

@Composable
private fun NotebookWithPageCount.displayTitle(): String =
    notebook.title.ifBlank { stringResource(R.string.untitled_notebook) }
