package com.sunlab.notebook.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.sunlab.notebook.data.models.NotebookEntity
import com.sunlab.notebook.data.models.NotebookWithPageCount
import com.sunlab.notebook.data.models.PageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NotebookDao {

    @Query(
        """
        SELECT n.*, (SELECT COUNT(*) FROM pages p WHERE p.notebookId = n.id) AS pageCount
        FROM notebooks n
        WHERE n.deletedAt IS NULL
        ORDER BY n.modifiedAt DESC
        """
    )
    fun observeActive(): Flow<List<NotebookWithPageCount>>

    @Insert
    suspend fun insertNotebook(notebook: NotebookEntity): Long

    @Insert
    suspend fun insertPage(page: PageEntity): Long

    @Query("UPDATE notebooks SET isFavorite = :favorite, modifiedAt = :now WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean, now: Long)
}
