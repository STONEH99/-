package com.sunlab.notebook.data.models

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class PageType { BLANK, RULED, GRID, DOTTED, CUSTOM }

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

@Entity(
    tableName = "notebooks",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.SET_NULL,
        ),
    ],
    indices = [Index("folderId")],
)
data class NotebookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    /** ARGB cover color. */
    val coverColor: Int,
    /** Cover design identifier (only "PLAIN" exists so far). */
    val coverStyle: String = "PLAIN",
    val coverImagePath: String? = null,
    val folderId: Long? = null,
    val isFavorite: Boolean = false,
    /** Reserved for password lock; not used by the UI yet. */
    val passwordHash: String? = null,
    val createdAt: Long,
    val modifiedAt: Long,
    /** Non-null means the notebook is in the trash. Reserved; trash UI not built yet. */
    val deletedAt: Long? = null,
)

@Entity(
    tableName = "pages",
    foreignKeys = [
        ForeignKey(
            entity = NotebookEntity::class,
            parentColumns = ["id"],
            childColumns = ["notebookId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("notebookId")],
)
data class PageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val notebookId: Long,
    val position: Int,
    val pageType: String = PageType.BLANK.name,
    val backgroundImagePath: String? = null,
    /** Serialized drawing content. Format will be defined with the editor. */
    val contentJson: String = "",
    val createdAt: Long,
    val modifiedAt: Long,
)

data class NotebookWithPageCount(
    @Embedded val notebook: NotebookEntity,
    val pageCount: Int,
)
