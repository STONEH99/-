package com.sunlab.notebook.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = PrimaryLavender,
    onPrimary = InkBlack,
    primaryContainer = SoftLavender,
    onPrimaryContainer = InkBlack,
    secondary = DeepLavender,
    onSecondary = PaperWhite,
    background = BackgroundLight,
    onBackground = InkBlack,
    surface = PaperWhite,
    onSurface = InkBlack,
    surfaceVariant = SoftLavender,
    onSurfaceVariant = SecondaryTextLight,
    outline = MutedGray,
    outlineVariant = BorderLight,
)

private val DarkColors = darkColorScheme(
    primary = PrimaryLavender,
    onPrimary = InkBlack,
    primaryContainer = DeepLavender,
    onPrimaryContainer = PaperWhite,
    secondary = PrimaryLavender,
    onSecondary = InkBlack,
    background = BackgroundDark,
    onBackground = SoftLavender,
    surface = SurfaceDark,
    onSurface = SoftLavender,
    surfaceVariant = BorderDark,
    onSurfaceVariant = MutedGray,
    outline = MutedGray,
    outlineVariant = BorderDark,
)

@Composable
fun SunLabTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = SunLabTypography,
        content = content,
    )
}
