package com.sunlab.notebook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunlab.notebook.ui.home.HomeScreen
import com.sunlab.notebook.ui.home.HomeViewModel
import com.sunlab.notebook.ui.theme.SunLabTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as SunLabApp
        setContent {
            SunLabTheme {
                val viewModel: HomeViewModel = viewModel(factory = HomeViewModel.factory(app))
                HomeScreen(viewModel)
            }
        }
    }
}
