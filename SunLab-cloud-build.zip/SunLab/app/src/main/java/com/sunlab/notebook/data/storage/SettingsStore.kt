package com.sunlab.notebook.data.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class LibraryLayout { GRID, LIST }

private val Context.settingsDataStore by preferencesDataStore(name = "settings")

class SettingsStore(private val context: Context) {

    private val layoutKey = stringPreferencesKey("library_layout")

    val libraryLayout: Flow<LibraryLayout> = context.settingsDataStore.data.map { prefs ->
        prefs[layoutKey]
            ?.let { saved -> LibraryLayout.entries.firstOrNull { it.name == saved } }
            ?: LibraryLayout.GRID
    }

    suspend fun setLibraryLayout(layout: LibraryLayout) {
        context.settingsDataStore.edit { it[layoutKey] = layout.name }
    }
}
