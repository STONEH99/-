package com.sunlab.notebook.ui.theme

import androidx.compose.material3.Typography

// Uses the system default font for now. Bundled fonts (Noto Sans/Naskh Arabic,
// Tajawal, Inter, Roboto) and custom TTF/OTF import are NOT implemented yet.
val SunLabTypography = Typography()
