package com.sunlab.notebook.ui.theme

import androidx.compose.ui.graphics.Color

// Palette from the project brief.
val PrimaryLavender = Color(0xFFA78BFA)
val DeepLavender = Color(0xFF8064C7)
val SoftLavender = Color(0xFFEDE7FA)
val BackgroundLight = Color(0xFFF7F3FC)
val PaperWhite = Color(0xFFFFFEFC)
val InkBlack = Color(0xFF292633)
val MutedGray = Color(0xFF96919F)
val BorderLight = Color(0xFFE6E0ED)

// Dark-mode values are derived from the same hues (not specified in the brief).
val BackgroundDark = Color(0xFF17141F)
val SurfaceDark = Color(0xFF211D2B)
val BorderDark = Color(0xFF3A3548)

// Muted Gray (#96919F) is too low-contrast for body text on paper white,
// so secondary text uses a darker tone of the same hue.
val SecondaryTextLight = Color(0xFF6B6676)
