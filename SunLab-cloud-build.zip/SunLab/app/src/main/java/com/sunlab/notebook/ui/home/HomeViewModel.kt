package com.sunlab.notebook.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sunlab.notebook.SunLabApp
import com.sunlab.notebook.data.models.NotebookWithPageCount
import com.sunlab.notebook.data.repository.NotebookRepository
import com.sunlab.notebook.data.storage.LibraryLayout
import com.sunlab.notebook.data.storage.SettingsStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val loaded: Boolean = false,
    val notebooks: List<NotebookWithPageCount> = emptyList(),
    val layout: LibraryLayout = LibraryLayout.GRID,
)

class HomeViewModel(
    private val repository: NotebookRepository,
    private val settings: SettingsStore,
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        repository.notebooks,
        settings.libraryLayout,
    ) { notebooks, layout ->
        HomeUiState(loaded = true, notebooks = notebooks, layout = layout)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun createNotebook(title: String) {
        viewModelScope.launch {
            repository.createNotebook(title.trim(), DEFAULT_COVER_COLOR)
        }
    }

    fun toggleFavorite(item: NotebookWithPageCount) {
        viewModelScope.launch {
            repository.setFavorite(item.notebook.id, !item.notebook.isFavorite)
        }
    }

    fun setLayout(layout: LibraryLayout) {
        viewModelScope.launch { settings.setLibraryLayout(layout) }
    }

    companion object {
        /** Deep Lavender (#8064C7) as ARGB. Cover color selection is not built yet. */
        const val DEFAULT_COVER_COLOR: Int = 0xFF8064C7.toInt()

        fun factory(app: SunLabApp): ViewModelProvider.Factory = viewModelFactory {
            initializer { HomeViewModel(app.notebookRepository, app.settings) }
        }
    }
}
