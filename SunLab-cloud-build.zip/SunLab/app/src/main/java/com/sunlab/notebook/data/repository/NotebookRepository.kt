package com.sunlab.notebook.data.repository

import androidx.room.withTransaction
import com.sunlab.notebook.data.database.SunLabDatabase
import com.sunlab.notebook.data.models.NotebookEntity
import com.sunlab.notebook.data.models.NotebookWithPageCount
import com.sunlab.notebook.data.models.PageEntity
import kotlinx.coroutines.flow.Flow

class NotebookRepository(private val db: SunLabDatabase) {

    private val dao = db.notebookDao()

    val notebooks: Flow<List<NotebookWithPageCount>> = dao.observeActive()

    /** Creates a notebook together with its first blank page, atomically. */
    suspend fun createNotebook(title: String, coverColor: Int): Long {
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val id = dao.insertNotebook(
                NotebookEntity(
                    title = title,
                    coverColor = coverColor,
                    createdAt = now,
                    modifiedAt = now,
                )
            )
            dao.insertPage(
                PageEntity(
                    notebookId = id,
                    position = 0,
                    createdAt = now,
                    modifiedAt = now,
                )
            )
            id
        }
    }

    suspend fun setFavorite(id: Long, favorite: Boolean) {
        dao.setFavorite(id, favorite, System.currentTimeMillis())
    }
}
