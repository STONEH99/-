# Build 🌞🥼 in the cloud with GitHub Actions

This project includes `.github/workflows/android-build.yml`.

## Run the build
1. Create a GitHub repository for this project.
2. Upload the **contents of the `SunLab` folder** to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Android Debug APK**.
5. Tap **Run workflow** (or push a commit to `main`/`master`).
6. Wait for the workflow to finish. A green check means the debug build completed.
7. Open the completed workflow run, find **Artifacts**, and download `SunLab-debug-apk`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.

The workflow installs Java 17 and Android SDK platform 35/build-tools 35.0.0, then runs `:app:assembleDebug`.

A successful cloud build is the first real compile verification. It does not replace testing the APK on a physical Android device.
