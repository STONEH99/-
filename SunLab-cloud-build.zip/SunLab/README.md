# 🌞🥼 (SunLab)

Android notebook application. Package: `com.sunlab.notebook`. Min SDK 26.

Kotlin · Jetpack Compose · Material 3 · MVVM · Room · DataStore · Coroutines/Flow.

## Status: Stage 1.1 (stabilization pass) — STILL NOT COMPILED

A second pass reviewed every file by hand (imports, Room entities/DAO/transaction,
DataStore, Compose APIs, resources, manifest). Changes: added the explicit
`material-icons-core` dependency, removed an unused import/argument, replaced a
sloppy `Spacer`. This was a read-through only; **no build has succeeded**, because
the sandbox still has no Android SDK and no access to the dependency repositories.

The source was written in a sandbox with **no Android SDK and no access to
Google Maven / Maven Central / the Gradle plugin portal**, so it has **never
been compiled or run**. Expect to fix a few compile errors on first build.
The only build attempt made (`gradle --offline :app:assembleDebug`) failed at
plugin resolution (`com.android.application:8.7.3` could not be downloaded),
before any Kotlin was compiled.

## Build instructions (APK)

Requirements: JDK 17+ (JDK 21 works), Android SDK with platform 35 and
build-tools, internet access for dependencies.

1. Open the `SunLab` folder in Android Studio (Ladybug or newer), let it sync; **or**
2. From a terminal:
   ```
   echo "sdk.dir=/path/to/Android/Sdk" > local.properties
   ./gradlew :app:assembleDebug
   ```
   The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

The wrapper pins Gradle 8.9 (required by AGP 8.7.3).

Versions: AGP 8.7.3 · Kotlin 2.0.21 (+ Compose compiler plugin) · KSP 2.0.21-1.0.28 ·
Compose BOM 2024.12.01 · Room 2.6.1 · DataStore 1.1.1 · Activity-Compose 1.9.3 ·
Lifecycle 2.8.7.

## Feature report

### Written in source, untested (never compiled or run)
- Project skeleton, Gradle config, manifest, launcher icon (original sun mark).
- Arabic-first strings (default locale) + English (`values-en`), RTL enabled.
- Light/dark Material 3 theme using the brief's palette (dark values derived).
- Room database v1: `folders`, `notebooks`, `pages` tables; DAO; repository.
- DataStore: persisted library layout (grid/list).
- Home screen: app name, notebook library, grid/list toggle, create-notebook
  (dialog + FAB), per-notebook favorite toggle, page count, empty state.
  Creating a notebook also creates its first blank page in one transaction.

### Not implemented yet (no UI exists for these; nothing is faked)
Folders navigation, Favorites screen, Search, Settings, notebook editing
(title, covers, gallery covers, color), password lock, duplicate, delete,
trash/recovery, page management (types, add/delete/duplicate/reorder, swipe),
editor (pen/pencil/highlighter/eraser/text/undo/redo/zoom), image editing,
camera, audio notes, page templates, PDF export, PNG export, backup/restore,
bundled fonts and custom TTF/OTF import, manual dark/light switch.

Note: columns for covers, folders, password hash and trash (`deletedAt`) exist in
the schema already so later stages need fewer migrations, but nothing uses them yet.

### Known deviations / notes
- Notebook cover has a single plain style with the default Deep Lavender color.
- Secondary text uses `#6B6676` instead of Muted Gray `#96919F` (too low contrast).
- Packages `ui/notebook`, `ui/editor`, `ui/folders`, `ui/favorites`, `ui/search`,
  `ui/settings`, `export`, `audio`, `security` will be created when they get code.

## Planned next stages
2. Verify build; navigation; notebook detail + page list.
3. Editor canvas (pen/eraser/undo/redo), autosave.
4. Notebook management (covers, folders, favorites screen, search, trash).
5. Images, audio, PDF/PNG export, backup/restore, locks, fonts, settings.
